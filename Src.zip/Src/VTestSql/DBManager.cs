﻿using System;
using System.Data;
using System.Data.SqlClient;

using VLog;
// Класс общения с БД на минималках (С). Мне нравится.
// В реальном ПО разнес бы на два-три проекта, если чистую SQL универсалку делать. Либо Entity Framework "от кода".
// Запросы и вообще все стринги здесь специально, так читать удобнее, а не бегать по классам и т.д.
// Была идея сделать эту штуку синглтоном, но смысла особого мало. Как и фабрика не в тему была бы.
namespace VTestSql
{
    public class DBManager
    {
        static private string _vtMaster = "master";
        static private string _vtTest = "VtTest";

        static private string _vtConn = @"Server=.\SQLEXPRESS;Integrated security=SSPI;database=";

        static private void CreateDatabase()
        {
            using (var connection = new SqlConnection($"{_vtConn}{_vtMaster}"))
            {
                try
                {
                    connection.Open();
                    var command = connection.CreateCommand();
                    command.CommandText = $"IF NOT EXISTS (SELECT * FROM sys.databases WHERE name = '{_vtTest}') CREATE DATABASE [{_vtTest}] ";
                    command.ExecuteNonQuery();

                    command.CommandText = $"USE [{_vtTest}] IF NOT EXISTS (SELECT * FROM sysobjects WHERE name = 'Products' and xtype = 'U') CREATE TABLE Products ([Id] [int] PRIMARY KEY IDENTITY(1, 1), [Code] [nvarchar](255) NOT NULL, [Quantity] [int] NOT NULL)";
                    command.ExecuteNonQuery();

                    connection.Close();
                }
                catch (Exception ex)
                {
                    VLogger.GetFileLogger(@"Log\", "VSql.log")?.Log(VLogger.LogLevel.ERROR, ex.Message);
                }
            }
        }

        static public void AddProduct(string code, int quantity, string connStr = "")
        {
            if (!string.IsNullOrEmpty(connStr))
                _vtConn = connStr;

            CreateDatabase(); // Производительность мимо, это специально

            using (var connection = new SqlConnection($"{_vtConn}{_vtTest}"))
            {
                try
                {
                    connection.Open();
                    var command = connection.CreateCommand();
                    command.CommandText = $"IF NOT EXISTS (SELECT * FROM Products WHERE code = '{code}') INSERT INTO Products (Code, Quantity) VALUES ('{code}', {quantity}) ELSE UPDATE Products SET Quantity = Quantity + {quantity} WHERE Code = '{code}'";
                    command.ExecuteNonQuery();

                    connection.Close();
                }
                catch (Exception ex)
                {
                    VLogger.GetFileLogger(@"Log\", "VSql.log")?.Log(VLogger.LogLevel.ERROR, ex.Message);
                }
            }
        }

        static public DataSet GetAll(string connStr = "")
        {
            if (!string.IsNullOrEmpty(connStr))
                _vtConn = connStr;

            CreateDatabase();

            using (var connection = new SqlConnection($"{_vtConn}{_vtTest}"))
            {
                try
                {
                    connection.Open();
                    var sql = $"SELECT Code, Quantity FROM Products ORDER BY Code ASC";
                    SqlDataAdapter adapter = new SqlDataAdapter(sql, connection);

                    DataSet products = new DataSet();
                    adapter.Fill(products, "Products");

                    connection.Close();
                    return products;
                }
                catch (Exception ex)
                {
                    VLogger.GetFileLogger(@"Log\", "VSql.log")?.Log(VLogger.LogLevel.ERROR, ex.Message);
                }
            }
            return null;
        }
    }
}
