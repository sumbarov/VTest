﻿using System;
using System.Windows.Forms;

using VTest.Data;
using VLog;

namespace VTest
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void textBoxQuantity_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsDigit(e.KeyChar))
                e.Handled = true;
            // Тут бекспейс отключен, это не ошибка
        }

        private void buttonAdd_Click(object sender, EventArgs e)
        {
            string code = textBoxCode.Text;
            string quantity = textBoxQuantity.Text;

            //Add it
            if (string.IsNullOrEmpty(code) || string.IsNullOrEmpty(quantity))
            {
                //Right now it doesn't matter what 2do
                return;
            }

            try
            {
                var item = new ListViewItem(new[] { code, quantity });
                ListViewItem newItem = listViewProducts.Items.Add(item);
                newItem.Tag = Products.Add(code, Convert.ToInt32(quantity));

                textBoxCode.Text = string.Empty;
                textBoxQuantity.Text = string.Empty;
            }
            catch (Exception ex)
            {
                // Именование логгеров выносить не буду, лишний код
                VLogger.GetFileLogger(@"Log\", "VClient.log")?.Log(VLogger.LogLevel.ERROR, ex.Message);
            }
        }

        private void initListView()
        {
            //Something
        }

        private void buttonDelete_Click(object sender, EventArgs e)
        {
            // This is not needed, it will not help: Products.IsAvailable2Delete(id);

            if (0 == listViewProducts.SelectedItems.Count)
                return;

            try
            {
                ListViewItem item = listViewProducts.SelectedItems[0];
                int id = Convert.ToInt32(item.Tag);
                if (Products.Delete(id))
                {
                    listViewProducts.Items.Remove(item);
                } else
                {
                    buttonDelete.Enabled = false;
                }
            }
            catch (Exception ex)
            {
                VLogger.GetFileLogger(@"Log\", "VClient.log")?.Log(VLogger.LogLevel.ERROR, ex.Message);
            }

        }

        private void textBoxCode_TextChanged(object sender, EventArgs e)
        {
            CheckPrNotEmpty();
        }

        private void textBoxQuantity_TextChanged(object sender, EventArgs e)
        {
            CheckPrNotEmpty();
        }

        private void CheckPrNotEmpty()
        {
            buttonAdd.Enabled = ! (string.IsNullOrEmpty(textBoxCode.Text) || string.IsNullOrEmpty(textBoxQuantity.Text));
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            initListView();
        }

        private void listViewProducts_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (0 == listViewProducts.SelectedItems.Count)
            {
                buttonDelete.Enabled = false;
                return;
            }

            try
            {
                int id = Convert.ToInt32(listViewProducts.SelectedItems[0].Tag);
                buttonDelete.Enabled = Products.IsAvailable2Delete(id);
            }
            catch (Exception ex)
            {
                VLogger.GetFileLogger(@"Log\", "VClient.log")?.Log(VLogger.LogLevel.ERROR, ex.Message);
            }
        }
    }
}
