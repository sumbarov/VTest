﻿namespace VLog
{
    public interface IVLogger
    {
        void Log(VLogger.LogLevel errorLevel, string message);
    }
}
