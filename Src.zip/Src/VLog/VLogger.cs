﻿using System;
using System.Collections.Generic;
using System.IO;

using VLog.Dev;

namespace VLog
{
    public static class VLogger
    {
        static readonly object MyLock = new object();
        static private Dictionary<string, VFileLogger> s_fileLoggers = new Dictionary<string, VFileLogger>();

        static public IVLogger GetFileLogger(string filePath, string fileName = "MyLog.log")
        {
            if (string.IsNullOrEmpty(filePath) || string.IsNullOrEmpty(fileName))
            {
                // Все ошибки пока наверх кидаю, это абсрактный логгер в вакууме, шут знает что с ними делать,
                // зависит от реальной задачи
                throw new ArgumentNullException("Something goes wrong..");
            }

            string key = Path.Combine(filePath, fileName);

            VFileLogger logger;                        
            if (!s_fileLoggers.TryGetValue(key, out logger))
            {
                lock (MyLock)
                {
                    logger = new VFileLogger(filePath, fileName);
                    logger.SetBackupMethod(BackupMethods.ClassicZip);
                    s_fileLoggers.Add(key, logger);
                }
            }
            return logger;
        }

        public enum LogLevel
        {
            TRACE, INFO, DEBUG, WARNING, ERROR
        }
    }
}
