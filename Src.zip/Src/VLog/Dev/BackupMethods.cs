﻿using System;
using System.Globalization;
using System.IO;
using System.IO.Compression;

namespace VLog.Dev
{
    static public class BackupMethods
    {
        static public bool ClassicZip(string fullPath)
        {
            try
            {
                // Индексация архивов мне не нравится, в вакууме можно и так
                var timeStamp = DateTime.UtcNow.ToString("yyyyMMddHHmmssfff", CultureInfo.InvariantCulture);
                string fileName = Path.GetFileName(fullPath);
                string zipName = $"{timeStamp}_{fileName}";
                string zipFullPath = Path.Combine(Path.GetDirectoryName(fullPath), zipName);

                FileInfo fi = new FileInfo(fullPath);
                fi.MoveTo(zipFullPath);

                // Временное решение
                using (FileStream fs = new FileStream($"{zipFullPath}.zip", FileMode.Create))
                using (ZipArchive arch = new ZipArchive(fs, ZipArchiveMode.Create))
                {
                    arch.CreateEntryFromFile(zipFullPath, zipName);
                }

                fi.Delete();
            }
            catch (Exception ex)
            {
                // Same shit, в реализации видно будет,
                // в консоль, окошко или еще куда
                throw ex;
            }

            return true;
        }
    }
}
