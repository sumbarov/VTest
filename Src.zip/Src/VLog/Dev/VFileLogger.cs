﻿using System;
using System.Globalization;
using System.IO;
using System.IO.Compression;
using System.Xml.Linq;

namespace VLog.Dev
{
    class VFileLogger : IVLogger
    {
        static readonly object MyLock = new object();

        private readonly DirectoryInfo _fileFolder;
        private readonly string _fullPath;

        private const long _maxSize = 1024;

        private Func<string, bool> _backupFile;
        private bool _isBackupActivated = false;

        public VFileLogger(string filePath, string fileName = "MyLog.log")
        {
            lock (MyLock) // <<-- От греха подальше..
            {
                if (string.IsNullOrEmpty(filePath) || string.IsNullOrEmpty(fileName))
                {
                    // Все ошибки пока наверх кидаю, это абсрактный логгер в вакууме, шут знает что с ними делать,
                    // зависит от реальной задачи
                    throw new ArgumentNullException("Something goes wrong..");
                }

                try
                {
                    _fileFolder = new DirectoryInfo(filePath);

                    if (!_fileFolder.Exists)
                        _fileFolder.Create();

                    _fullPath = Path.Combine(filePath, fileName);
                }
                catch (Exception ex)
                {
                    // Same shit, в реализации видно будет,
                    // в консоль, окошко или еще куда
                    throw ex;
                }
            }
        }

        ~VFileLogger()
        {
            // NB: Пригодится.. что-то хотел попробовать, надо вспомнить.
        }

        private void CheckFileSize()
        {
            FileInfo fi = new FileInfo(_fullPath);

            if (_isBackupActivated && fi.Exists && fi.Length > _maxSize)
                _backupFile(_fullPath);
        }

        public void SetBackupMethod(Func<string, bool> backupMethod)
        {
            _backupFile = backupMethod;
            _isBackupActivated = true;
        }

        public void Log(VLogger.LogLevel errorLevel, string message)
        {
            lock (MyLock)
            {
                if (string.IsNullOrEmpty(message))
                    throw new ArgumentNullException("Something goes wrong..");

                _fileFolder.Refresh();
                if (!_fileFolder.Exists) // Параноик, вдруг папку грохнули, бывало
                    _fileFolder.Create();

                CheckFileSize();

                var timeStamp = DateTime.UtcNow.ToString("dd-MM-yyyy HH:mm:ss.fff", CultureInfo.InvariantCulture);
                try
                {
                    // На производительность временно забили
                    XElement elem = new XElement("Message",
                               new XElement("DateTime", timeStamp),
                               new XElement("Level", errorLevel),
                               new XElement("Message", message));

                    if (File.Exists(_fullPath))
                    {
                        XDocument doc = XDocument.Load(_fullPath);
                        doc.Element("Wrapper").Add(elem);
                        doc.Save(_fullPath);
                    }
                    else
                    {
                        XElement wrapper = new XElement("Wrapper");
                        wrapper.Add(new XAttribute("DateTime", timeStamp));
                        XDocument doc = new XDocument(new XDeclaration("0.1", "utf-8", "yes"), wrapper);
                        wrapper.Add(elem);
                        doc.Save(_fullPath);
                    }
                }
                catch (Exception ex)
                {
                    // Same shit, в реализации видно будет,
                    // в консоль, окошко или еще куда
                    throw ex;
                }
            }
        }
    }
}
