﻿namespace VLog
{
    class Test
    {
        static void TestMe()
        {
            string message = "Hi Everyone!";
            string path = @"c:\Development\C#\Log\";

            IVLogger logger = VLogger.GetFileLogger(path);
            logger?.Log(VLogger.LogLevel.ERROR, message);
        }
    }
}
