﻿using System.Runtime.Serialization;

using VTestSql;

[DataContract]
public class ProductData : IProductData
{
    [DataMember]
    public int ProductId; //Пусто, для расширения пригодится
    [DataMember]
    public string Code;
    [DataMember]
    public int Quantity;
    [DataMember]
    public string When; //Пусто, для расширения пригодится

    public ProductData(string code, int quantity)
    {
        Code = code;
        Quantity = quantity;
    }

    public ProductData()
    {
    }

    public bool SendData(ProductData item)
    {
        //For extensions (на будущее пригодилось бы)
        Code = item.Code;
        Quantity = item.Quantity;

        DBManager.AddProduct(Code, Quantity);

        return true;
    }
}
