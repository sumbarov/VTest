﻿using System.ServiceModel;

[ServiceContract]
public interface IProductData
{
    [OperationContract]
    bool SendData(ProductData item);
}
