﻿using System;
using System.ServiceModel;
using System.Threading;

using VLog;

namespace VTest.Data
{
    public class Product
    {
        #pragma warning disable 0169
        private int _productId;  //Пусто, для расширения пригодится
        private string _when;  //Пусто, для расширения пригодится
        #pragma warning restore 0169

        public int Quantity { get; }
        public string Code { get; }
        public bool Sent { get; set; }

        private Thread _hndl;

        public Product(string code, int quantity)
        {
            //Проверок не будет
            Code = code;
            Quantity = quantity;
            Sent = false;
        }

        public void Send()
        {
            _hndl = new Thread(Run);
            _hndl.Start();
        }

        public void Abort()
        {
            _hndl.Abort();
        }

        private void Run()
        {
            Thread.Sleep(5000);
            ProductData item = new ProductData(Code, Quantity);
            Sent = SendData(item);
        }

        private bool SendData(ProductData item)
        {
            try
            {
                // Специально прописано жестко в коде
                var serviceAddress = "127.0.0.1:10000";
                var serviceName = "VTestSrv";

                Uri tcpUri = new Uri($"net.tcp://{serviceAddress}/{serviceName}");
                EndpointAddress address = new EndpointAddress(tcpUri);
                NetTcpBinding clientBinding = new NetTcpBinding();
                ChannelFactory<IProductData> factory = new ChannelFactory<IProductData>(clientBinding, address);
                var service = factory.CreateChannel();

                service.SendData(item);
                return true;
            }
            catch (Exception ex)
            {
                //Что-то не хорошо нам, для тестового задания без обработки, сервер не отвечает и т.д.
                VLogger.GetFileLogger(@"Log\", "VData.log")?.Log(VLogger.LogLevel.ERROR, ex.Message);
            }
            return false;
        }
    }
}
