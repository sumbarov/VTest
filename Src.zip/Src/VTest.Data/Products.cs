﻿using System.Collections.Generic;

namespace VTest.Data
{
    static public class Products
    {
        static private Dictionary<int, Product> s_productsPool = new Dictionary<int, Product>();
        static private int _key = 0;

        static public int Add(string code, int quantity)
        {
            Product item = new Product(code, quantity);
            s_productsPool.Add(++_key, item);
            item.Send();

            return _key;
        }

        static public bool Delete(int id)
        {
            Product item;
            if (s_productsPool.TryGetValue(id, out item) && IsAvailable2Delete(id))
            {
                item.Abort();
                s_productsPool.Remove(id);
                return true;
            }
            return false;
        }

        static public bool IsAvailable2Delete(int id)
        {
            Product item;
            if (s_productsPool.TryGetValue(id, out item))
            {
                return !item.Sent;
            }
            return true;
        }
    }
}
