﻿using System;
using System.Collections.Generic;
using System.Data;
using System.ServiceModel;
using System.Text;
using System.Configuration;

using VTestSql;
using VLog;

namespace VTestSrv
{
    class Program
    {
        static void Main(string[] args)
        {
            IVLogger logger = VLogger.GetFileLogger(@"Log\", "VSrv.log");
            logger?.Log(VLogger.LogLevel.INFO, "Server started.");

            try
            {
                // Не хочу выносить в App.config, в отличии от строчки коннекта, в абстрактном тесте не ясно,
                //  где оптимальнее все держать.
                var serviceAddress = "127.0.0.1:10000";
                var serviceName = "VTestSrv";

                var host = new ServiceHost(typeof(ProductData), new Uri($"net.tcp://{serviceAddress}/{serviceName}"));
                var serverBinding = new NetTcpBinding();
                host.AddServiceEndpoint(typeof(IProductData), serverBinding, "");
                host.Open();

                string connStr = ConfigurationManager.ConnectionStrings["vtConnectionString"]?.ConnectionString;
                DataSet ds = DBManager.GetAll(connStr); //Если ругаться будет - не проблема
                if (null != ds)
                {
                    Console.WriteLine(ds.ToConsole());
                }
            }
            catch (Exception ex)
            {
                logger?.Log(VLogger.LogLevel.ERROR, ex.Message);
            }
            Console.ReadKey();
            logger?.Log(VLogger.LogLevel.INFO, "Close");
        }
    }

    // Just wanted to add it here. (с) Можно и без этого обойтись.
    static class ExtensionMethods
    {
        static public string ToConsole(this DataSet ds)
        {
            var sb = new StringBuilder();
            foreach (var table in ds.Tables.ToList())
            {
                sb.AppendLine("--" + table.TableName + "--");
                sb.AppendLine(String.Join(" | ", table.Columns.ToList()));
                foreach (DataRow row in table.Rows)
                {
                    sb.AppendLine(String.Join(" | ", row.ItemArray));
                }
                sb.AppendLine();
            }
            return sb.ToString();
        }

        static public List<DataTable> ToList(this DataTableCollection collection)
        {
            var list = new List<DataTable>();
            foreach (var table in collection)
            {
                list.Add((DataTable)table);
            }
            return list;
        }

        static public List<DataColumn> ToList(this DataColumnCollection collection)
        {
            var list = new List<DataColumn>();
            foreach (var column in collection)
            {
                list.Add((DataColumn)column);
            }
            return list;
        }
    }
}
